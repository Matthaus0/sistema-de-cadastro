// Classe que representa cada cliente cadastrado.
class Cliente {
    constructor(nome, email, telefone, cpf, cidade) {
        this.id = crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random());
        this.nome = nome.trim();
        this.email = email.trim().toLowerCase();
        this.telefone = telefone.trim();
        this.cpf = cpf.trim();
        this.cidade = cidade.trim();
        this.criadoEm = new Date().toISOString();
    }
}

// Classe responsável pelas operações dos clientes.
class GerenciadorClientes {
    constructor() {
        this.chave = 'cadastroClientesTDS';
        this.clientes = this.carregar();
    }

    carregar() {
        try {
            const dados = JSON.parse(localStorage.getItem(this.chave));
            return Array.isArray(dados) ? dados : [];
        } catch {
            return [];
        }
    }

    salvar() {
        localStorage.setItem(this.chave, JSON.stringify(this.clientes));
    }

    adicionar(cliente) {
        const emailExiste = this.clientes.some(
            c => c.email.toLowerCase() === cliente.email.toLowerCase()
        );
        if (emailExiste) {
            throw new Error('Já existe um cliente cadastrado com esse e-mail.');
        }

        if (
            cliente.cpf &&
            this.clientes.some(c => somenteNumeros(c.cpf) === somenteNumeros(cliente.cpf))
        ) {
            throw new Error('Já existe um cliente cadastrado com esse CPF.');
        }

        this.clientes.push(cliente);
        this.salvar();
    }

    atualizar(id, dados) {
        const emailExiste = this.clientes.some(
            c => c.id !== id && c.email.toLowerCase() === dados.email.toLowerCase()
        );
        if (emailExiste) {
            throw new Error('Outro cliente já utiliza esse e-mail.');
        }

        if (
            dados.cpf &&
            this.clientes.some(c => c.id !== id && somenteNumeros(c.cpf) === somenteNumeros(dados.cpf))
        ) {
            throw new Error('Outro cliente já utiliza esse CPF.');
        }

        this.clientes = this.clientes.map(c =>
            c.id === id ? { ...c, ...dados, email: dados.email.trim().toLowerCase() } : c
        );
        this.salvar();
    }

    remover(id) {
        this.clientes = this.clientes.filter(c => c.id !== id);
        this.salvar();
    }

    limpar() {
        this.clientes = [];
        this.salvar();
    }

    buscar(termo) {
        const busca = termo.toLowerCase().trim();
        return this.clientes.filter(c =>
            [c.nome, c.email, c.telefone, c.cpf, c.cidade].some(valor =>
                (valor || '').toLowerCase().includes(busca)
            )
        );
    }
}

// Criando o gerenciador.
const gerenciador = new GerenciadorClientes();

// Selecionando os elementos HTML.
const form = document.getElementById('formCliente');
const campoId = document.getElementById('clienteId');
const campoNome = document.getElementById('nome');
const campoEmail = document.getElementById('email');
const campoTelefone = document.getElementById('telefone');
const campoCpf = document.getElementById('cpf');
const campoCidade = document.getElementById('cidade');
const campoPesquisa = document.getElementById('pesquisa');
const campoOrdenacao = document.getElementById('ordenacao');
const lista = document.getElementById('listaClientes');
const total = document.getElementById('totalClientes');
const estadoVazio = document.getElementById('estadoVazio');
const mensagem = document.getElementById('mensagem');
const tituloFormulario = document.getElementById('tituloFormulario');
const botaoSalvar = document.getElementById('botaoSalvar');
const botaoCancelar = document.getElementById('botaoCancelar');

// Função para deixar somente números.
function somenteNumeros(valor) {
    return valor.replace(/\D/g, '');
}

// Formatação automática do telefone.
function formatarTelefone(valor) {
    const n = somenteNumeros(valor).slice(0, 11);
    if (n.length <= 2) return n;
    if (n.length <= 6) {
        return `(${n.slice(0, 2)}) ${n.slice(2)}`;
    }
    if (n.length <= 10) {
        return `(${n.slice(0, 2)}) ${n.slice(2, 6)}-${n.slice(6)}`;
    }
    return `(${n.slice(0, 2)}) ${n.slice(2, 7)}-${n.slice(7)}`;
}

// Formatação automática do CPF.
function formatarCpf(valor) {
    const n = somenteNumeros(valor).slice(0, 11);
    return n
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d)/, '$1.$2')
        .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
}

// Validação do CPF.
function cpfValido(cpf) {
    const n = somenteNumeros(cpf);
    if (n.length !== 11 || /^(\d)\1{10}$/.test(n)) {
        return false;
    }

    let soma = 0;
    for (let i = 0; i < 9; i++) {
        soma += Number(n[i]) * (10 - i);
    }
    let digito = (soma * 10) % 11;
    if (digito === 10) {
        digito = 0;
    }
    if (digito !== Number(n[9])) {
        return false;
    }

    soma = 0;
    for (let i = 0; i < 10; i++) {
        soma += Number(n[i]) * (11 - i);
    }
    digito = (soma * 10) % 11;
    if (digito === 10) {
        digito = 0;
    }
    return digito === Number(n[10]);
}

// Exibe mensagens na tela.
function mostrarMensagem(texto, tipo = '') {
    mensagem.textContent = texto;
    mensagem.className = `mensagem ${tipo}`.trim();
}

// Limpa o formulário.
function limparFormulario() {
    form.reset();
    campoId.value = '';
    tituloFormulario.textContent = 'Cadastrar cliente';
    botaoSalvar.textContent = 'Cadastrar cliente';
    botaoCancelar.hidden = true;
}

// Mostra os clientes na tabela.
function renderizarClientes() {
    const termo = campoPesquisa.value;
    let clientes = gerenciador.buscar(termo);

    // Organização dos clientes.
    if (campoOrdenacao.value === 'az') {
        clientes.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
    } else if (campoOrdenacao.value === 'za') {
        clientes.sort((a, b) => b.nome.localeCompare(a.nome, 'pt-BR'));
    } else {
        clientes.sort((a, b) => new Date(b.criadoEm) - new Date(a.criadoEm));
    }

    // Atualiza a quantidade de clientes.
    total.textContent = gerenciador.clientes.length;
    lista.replaceChildren();

    // Percorre todos os clientes.
    clientes.forEach(cliente => {
        const linha = document.createElement('tr');

        // Nome e e-mail.
        const colunaNome = document.createElement('td');
        const nome = document.createElement('span');
        nome.className = 'nome-cliente';
        nome.textContent = cliente.nome;

        const email = document.createElement('span');
        email.className = 'dado-secundario';
        email.textContent = cliente.email;

        colunaNome.append(nome, email);

        // Telefone.
        const colunaContato = document.createElement('td');
        colunaContato.textContent = cliente.telefone;

        // CPF.
        const colunaCpf = document.createElement('td');
        colunaCpf.textContent = cliente.cpf || '—';

        // Cidade.
        const colunaCidade = document.createElement('td');
        colunaCidade.textContent = cliente.cidade || '—';

        // Botões de ação.
        const colunaAcoes = document.createElement('td');
        colunaAcoes.className = 'coluna-acoes';

        const acoes = document.createElement('div');
        acoes.className = 'acoes-linha';

        // Botão editar.
        const editar = document.createElement('button');
        editar.type = 'button';
        editar.className = 'botao-pequeno editar';
        editar.textContent = 'Editar';
        editar.addEventListener('click', () => {
            iniciarEdicao(cliente.id);
        });

        // Botão excluir.
        const excluir = document.createElement('button');
        excluir.type = 'button';
        excluir.className = 'botao-pequeno excluir';
        excluir.textContent = 'Excluir';
        excluir.addEventListener('click', () => {
            excluirCliente(cliente.id);
        });

        acoes.append(editar, excluir);
        colunaAcoes.append(acoes);

        linha.append(colunaNome, colunaContato, colunaCpf, colunaCidade, colunaAcoes);
        lista.append(linha);
    });

    // Mostra mensagem quando não existem resultados.
    estadoVazio.classList.toggle('visivel', clientes.length === 0);
}

// Inicia a edição de um cliente.
function iniciarEdicao(id) {
    const cliente = gerenciador.clientes.find(c => c.id === id);
    if (!cliente) return;

    campoId.value = cliente.id;
    campoNome.value = cliente.nome;
    campoEmail.value = cliente.email;
    campoTelefone.value = cliente.telefone;
    campoCpf.value = cliente.cpf;
    campoCidade.value = cliente.cidade;

    tituloFormulario.textContent = 'Editar cliente';
    botaoSalvar.textContent = 'Salvar alterações';
    botaoCancelar.hidden = false;

    mostrarMensagem('Editando o cadastro selecionado.', 'sucesso');
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Exclui um cliente.
function excluirCliente(id) {
    const cliente = gerenciador.clientes.find(c => c.id === id);
    if (!cliente) return;

    if (!confirm(`Deseja realmente excluir o cadastro de ${cliente.nome}?`)) {
        return;
    }

    gerenciador.remover(id);

    if (campoId.value === id) {
        limparFormulario();
    }

    renderizarClientes();
    mostrarMensagem('Cliente excluído com sucesso.', 'sucesso');
}

// Evento de cadastro e edição.
form.addEventListener('submit'), event => {
    event.preventDefault();

    const nome = campoNome.value.trim();
    const email = campoEmail.value.trim();
    const telefone = campoTelefone.value.trim();
    const cpf = campoCpf.value.trim();
    const cidade = campoCidade.value.trim();
}
// Validação do nome.
if (nome.length < 3) {
    mostrarMensagem('Informe um nome com pelo menos 3 caracteres.', 'erro');
    campoNome.focus();
    return;
}

// Validação do telefone.
if (somenteNumeros(telefone).length < 10) {
    mostrarMensagem('Informe um telefone válido com DDD.', 'erro');
    campoTelefone.focus();
    return;
}

// Validação do CPF.
if (cpf && !cpfValido(cpf)) {
    mostrarMensagem('O CPF informado não é válido. Confira os números.', 'erro');
    campoCpf.focus();
    return;
}

try {
    // Se existe ID, atualiza o cadastro.
    if (campoId.value) {
        gerenciador.atualizar(campoId.value, { nome, email, telefone, cpf, cidade });
        mostrarMensagem('Cadastro atualizado com sucesso.', 'sucesso');
    } else {
        // Caso contrário, cria um novo cliente.
        gerenciador.adicionar(new Cliente(nome, email, telefone, cpf, cidade));
        mostrarMensagem('Cliente cadastrado com sucesso.', 'sucesso');
    }

    limparFormulario();
    renderizarClientes();
}